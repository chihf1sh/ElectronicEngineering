#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "main.h"
#include "mpu6050.h"
#include "moto_ctrl.h"

extern moto_ctrl_t g_moto_ctrl ;
extern mpu6050_t g_mpu6050 ;
