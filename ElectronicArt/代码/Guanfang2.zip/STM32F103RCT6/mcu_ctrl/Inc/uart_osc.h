#ifndef __UART_OSC_H
#define	__UART_OSC_H
#include "main.h"

void Uart_OSC_ShowWave(int a,int b,int c,int d);
#endif /*__UART_OSC_H */
