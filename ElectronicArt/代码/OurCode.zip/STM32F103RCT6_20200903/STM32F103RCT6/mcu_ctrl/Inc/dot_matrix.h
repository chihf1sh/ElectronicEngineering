#ifndef __DOT_MATRIX_H
#define	__DOT_MATRIX_H
#include "main.h"

void dot_matrix_init( void ) ;
void show_dot_matrix( void ) ;
void move_dot_matrix( void ) ;


#endif /* __I2C_MMA_H */


